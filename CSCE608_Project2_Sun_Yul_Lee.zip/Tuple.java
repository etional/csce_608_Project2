// class for tuple
public class Tuple
{
   public String a;
   public int b;
   
   // constructor
   public Tuple(int b_in, String a_in)
   {
      a = a_in;
      b = b_in;
   }
}